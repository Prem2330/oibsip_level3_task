import React from 'react'

const ordered = () => {
  return (
    <div>Thank you your order is successfully placed</div>
  )
}

export default ordered