import React from 'react'
import '../Styles.css'
import img1 from '../Images/pizza.jpg';

const img = () => {
  return (
    <div>
    <img src={img1}/>
    </div>
  )
}

export default img;