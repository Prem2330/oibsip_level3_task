import React from 'react'
import Img from './img';
import About from './About.jsx';

const home = () => {
  return (
    <div>
    <Img/>
   <About />
    </div>
  )
}

export default home;